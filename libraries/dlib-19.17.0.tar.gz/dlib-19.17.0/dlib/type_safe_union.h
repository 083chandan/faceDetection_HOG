// Copyright (C) 2009  Davis E. King (davis@dlib.net)
// License: Boost Software License   See LICENSE.txt for the full license.
#ifndef DLIB_TYPE_SAFE_UNIOn_TOP_
#define DLIB_TYPE_SAFE_UNIOn_TOP_ 

#include "type_safe_union/type_safe_union_kernel.h"

#endif // DLIB_TYPE_SAFE_UNIOn_TOP_



